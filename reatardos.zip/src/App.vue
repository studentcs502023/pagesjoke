<script setup>
import ia from "./components/generacion.vue"
</script>

<template>
  <ia></ia>
</template>

<style scoped>

</style>
